from django.apps import AppConfig


class CovidCheckerConfig(AppConfig):
    name = 'covid_checker'
