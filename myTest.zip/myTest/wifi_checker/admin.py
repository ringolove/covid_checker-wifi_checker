from django.contrib import admin
from .models import Wifi

# Register your models here.
admin.site.register(Wifi)