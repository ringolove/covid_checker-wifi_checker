from django.apps import AppConfig


class WifiCheckerConfig(AppConfig):
    name = 'wifi_checker'
