from django.shortcuts import render
from .models import Wifi
import csv

# Create your views here.
def index(request):
    wifiList = Wifi.objects.all()
    context = {'centerLat': wifiList[0].latitude, 'centerLon': wifiList[0].longitude, 'wifiList': wifiList}
    return render(request, 'wifi_checker/wifi_main.html', context)


#def detail(request, category):
#    wifiList = Wifi.objects.filter(svcProvdNm=category)
#    context = {'category': category, 'centerLat': wifiList[0].latitude, 'centerLon': wifiList[0].longitude, 'wifiList': wifiList}
#    return render(request, 'wifi_checker/wifi_main.html', context)


def bulk_import(request):
    CSV_PATH = 'static/wifi_list.csv'

    with open(CSV_PATH, newline='', encoding='euc-kr') as csvfile:
        data_reader = csv.DictReader(csvfile)
        for row in data_reader:
            Wifi.objects.create(
                instlCtprvnNm=row['설치시도명'],
                instlSignguNm=row['설치시군구명'],
                instlNm=row['설치장소명'],
                instlLcDesc=row['설치장소상세'],
                svcProvdNm=row['서비스제공사명'],
                latitude=row['WGS84위도'],
                longitude=row['WGS84경도'],
            )
    return
